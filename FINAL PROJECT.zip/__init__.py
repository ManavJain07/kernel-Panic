from . import access, guide, lesson, panel

# "guide" is the Nav Guide tab (goals, help, tool finder, learn a task).
modules = (access, lesson, panel, guide)


def register():
    for m in modules:
        m.register()


def unregister():
    for m in reversed(modules):
        m.unregister()
